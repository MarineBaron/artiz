--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Debian 10.5-1.pgdg90+1)
-- Dumped by pg_dump version 10.5 (Debian 10.5-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;


DROP DATABASE artiz;
--
-- Name: artiz; Type: DATABASE; Schema: -; Owner: artiz
--

CREATE DATABASE artiz WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'fr_FR.utf8' LC_CTYPE = 'fr_FR.utf8';


ALTER DATABASE artiz OWNER TO artiz;

\connect artiz

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner:
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner:
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Clients; Type: TABLE; Schema: public; Owner: artiz
--

CREATE TABLE public."Clients" (
    id integer NOT NULL,
    "erpId" integer,
    "artisanId" integer,
    "clientId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isErpSync" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Clients" OWNER TO artiz;

--
-- Name: Clients_id_seq; Type: SEQUENCE; Schema: public; Owner: artiz
--

CREATE SEQUENCE public."Clients_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Clients_id_seq" OWNER TO artiz;

--
-- Name: Clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: artiz
--

ALTER SEQUENCE public."Clients_id_seq" OWNED BY public."Clients".id;


--
-- Name: Products; Type: TABLE; Schema: public; Owner: artiz
--

CREATE TABLE public."Products" (
    id integer NOT NULL,
    qty real,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    description character varying(255),
    "projectId" integer,
    "erpId" integer,
    price real,
    tva_tx real
);


ALTER TABLE public."Products" OWNER TO artiz;

--
-- Name: Products_id_seq; Type: SEQUENCE; Schema: public; Owner: artiz
--

CREATE SEQUENCE public."Products_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Products_id_seq" OWNER TO artiz;

--
-- Name: Products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: artiz
--

ALTER SEQUENCE public."Products_id_seq" OWNED BY public."Products".id;


--
-- Name: Projects; Type: TABLE; Schema: public; Owner: artiz
--

CREATE TABLE public."Projects" (
    id integer NOT NULL,
    "artisanId" integer,
    name character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "clientId" integer,
    "erpId" integer,
    "isErpSync" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Projects" OWNER TO artiz;

--
-- Name: Projects_id_seq; Type: SEQUENCE; Schema: public; Owner: artiz
--

CREATE SEQUENCE public."Projects_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Projects_id_seq" OWNER TO artiz;

--
-- Name: Projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: artiz
--

ALTER SEQUENCE public."Projects_id_seq" OWNED BY public."Projects".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: artiz
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO artiz;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: artiz
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    username character varying(255),
    email character varying(255),
    password character varying(255),
    role character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    erpapikey character varying(255),
    name character varying(255)
);


ALTER TABLE public."Users" OWNER TO artiz;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: artiz
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO artiz;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: artiz
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: Clients id; Type: DEFAULT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Clients" ALTER COLUMN id SET DEFAULT nextval('public."Clients_id_seq"'::regclass);


--
-- Name: Products id; Type: DEFAULT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Products" ALTER COLUMN id SET DEFAULT nextval('public."Products_id_seq"'::regclass);


--
-- Name: Projects id; Type: DEFAULT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Projects" ALTER COLUMN id SET DEFAULT nextval('public."Projects_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Data for Name: Clients; Type: TABLE DATA; Schema: public; Owner: artiz
--

COPY public."Clients" (id, "erpId", "artisanId", "clientId", "createdAt", "updatedAt", "isErpSync") FROM stdin;
4	\N	1	11	2018-09-04 16:02:52.452+00	2018-09-08 14:30:46.196+00	f
3	9	1	10	2018-09-04 15:13:21.938+00	2018-09-09 21:04:08.837+00	t
2	8	1	4	2018-08-31 11:37:25.799+00	2018-09-09 21:28:38.385+00	t
\.


--
-- Data for Name: Products; Type: TABLE DATA; Schema: public; Owner: artiz
--

COPY public."Products" (id, qty, "createdAt", "updatedAt", description, "projectId", "erpId", price, tva_tx) FROM stdin;
121	0.610000014	2018-09-04 15:13:25.664+00	2018-09-09 21:04:08.853+00	Ceci est un produit.	25	36	1.71000004	5.5
125	6.21000004	2018-09-04 15:13:25.664+00	2018-09-09 21:04:08.854+00	Ceci est un produit.	25	37	5.30000019	10
124	1.50999999	2018-09-04 15:13:25.664+00	2018-09-09 21:04:08.865+00	Ceci est un produit.	25	38	9.05000019	10
123	6.17000008	2018-09-04 15:13:25.664+00	2018-09-09 21:04:08.875+00	Ceci est un produit.	25	39	2.88000011	5.5
112	1.22000003	2018-09-04 12:02:36.037+00	2018-09-09 21:28:38.399+00	Ceci est un produit.	21	31	1.04999995	20
113	8.90999985	2018-09-04 12:02:36.037+00	2018-09-09 21:28:38.404+00	Ceci est un produit.	21	33	7.17999983	5.5
115	1.48000002	2018-09-04 12:02:36.037+00	2018-09-09 21:28:38.405+00	Ceci est un produit.	21	34	9.22999954	5.5
114	2.96000004	2018-09-04 12:02:36.037+00	2018-09-09 21:28:38.413+00	Ceci est un produit.	21	32	1.02999997	5.5
\.


--
-- Data for Name: Projects; Type: TABLE DATA; Schema: public; Owner: artiz
--

COPY public."Projects" (id, "artisanId", name, "createdAt", "updatedAt", "clientId", "erpId", "isErpSync") FROM stdin;
25	1	Modifié par Artiz	2018-09-04 15:13:21.844+00	2018-09-09 21:04:08.844+00	10	15	t
21	1	Projet 2 - modifié depuis Dolibarr	2018-08-31 11:38:37.409+00	2018-09-09 21:28:57.762+00	4	14	t
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: artiz
--

COPY public."SequelizeMeta" (name) FROM stdin;
20180824115147-create-user.js
20180824115834-create-project.js
20180824132122-create-product.js
20180825153431-project-add-column-clientId.js
20180825154135-project-add-column-clientId.js
20180826094242-product-add-column-projectId.js
20180826094711-product-rename-column.js
20180826110709-product-refactor-projectId.js
20180826202401-user-add-dolapikey.js
20180828095007-create-client.js
20180828100623-projet-product-add-dolibarr-column.js
20180828102434-product-price-add-column.js
20180905174457-alter-fields-dolibarr-erp.js
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: artiz
--

COPY public."Users" (id, username, email, password, role, "createdAt", "updatedAt", erpapikey, name) FROM stdin;
3	artiz	artiz@artiz.fr	$2b$10$odP3TRLrgssrJ8vvJQQnFe1/N947zKitqfosISskQC8Sm449cXOMG	admin	2018-08-25 14:38:46.595+00	2018-09-08 14:30:16.804+00	\N	Administrateur
11	cli3	cli3@cli3.fr	$2b$10$WxW3oZ/6uA1zGRZ5nQRlxupfSJiEOXVAHXRtJFM.pPBdcjEb3NWuu	client	2018-09-04 16:02:25.986+00	2018-09-08 14:30:46.195+00	\N	Client 3
1	art1	art1@art1.fr	$2b$10$3Ek1/BA/XDWmoQczDa0L9.JCEcDY2ChmS5lWg8t7.RlxKhRMlGqdq	artisan	2018-08-25 11:03:17.987+00	2018-09-09 20:04:41.188+00	qHjoFe6W2AfOg1L4IL9k2Awy83k11TMy	Artisan 1
10	cli2	cli2@cli2.fr	$2b$10$4WBWdjX1HrhSnTk35Ed5degAOsSrmkqzZ7ABfOZlYVo1J3K5OpsxS	client	2018-09-04 15:12:43.157+00	2018-09-09 21:00:07.225+00	\N	Client 2
4	cli1	cli1@cli1.fr	$2b$10$BXeyNGEJX3.gS.0WL24xgeulKT9UQKtHKn6PmKcl5KqNEe/NBurBu	client	2018-08-25 14:57:35.861+00	2018-09-09 21:28:37.565+00	\N	Client 1
\.


--
-- Name: Clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: artiz
--

SELECT pg_catalog.setval('public."Clients_id_seq"', 5, true);


--
-- Name: Products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: artiz
--

SELECT pg_catalog.setval('public."Products_id_seq"', 160, true);


--
-- Name: Projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: artiz
--

SELECT pg_catalog.setval('public."Projects_id_seq"', 29, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: artiz
--

SELECT pg_catalog.setval('public."Users_id_seq"', 12, true);


--
-- Name: Clients Clients_pkey; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Clients"
    ADD CONSTRAINT "Clients_pkey" PRIMARY KEY (id);


--
-- Name: Products Products_pkey; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Products_pkey" PRIMARY KEY (id);


--
-- Name: Projects Projects_pkey; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_username_key; Type: CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key" UNIQUE (username);


--
-- Name: Clients Clients_artisanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Clients"
    ADD CONSTRAINT "Clients_artisanId_fkey" FOREIGN KEY ("artisanId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: Clients Clients_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Clients"
    ADD CONSTRAINT "Clients_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: Products Products_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Products"
    ADD CONSTRAINT "Products_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Projects"(id) ON DELETE CASCADE;


--
-- Name: Projects Projects_artisanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_artisanId_fkey" FOREIGN KEY ("artisanId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: Projects Projects_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: artiz
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--
