UPDATE public."Users" SET "erpapikey" = NULL;
UPDATE public."Clients" SET "erpId" = NULL, "isErpSync" = FALSE;
UPDATE public."Projects" SET "erpId" = NULL, "isErpSync" = FALSE;
UPDATE public."Products" SET "erpId" = NULL;
